
public class SubtractionOperation extends Operation {

	@Override
	public double getResult() {
		// TODO Auto-generated method stub
		Double result=this.getNum1()-this.getNum2();
		return result;
	}

}
