
public interface OperationFactory {

	public Operation getOperaction();
}
