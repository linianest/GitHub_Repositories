
public class AddOperationFactory implements OperationFactory {

	@Override
	public Operation getOperaction() {
		// TODO Auto-generated method stub
		return new AddOperation();
	}

}
