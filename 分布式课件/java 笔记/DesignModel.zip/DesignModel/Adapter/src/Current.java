
public class Current {

	public void user220V(){
		System.out.println("ʹ��220v��ѹ");
		
	}
}
