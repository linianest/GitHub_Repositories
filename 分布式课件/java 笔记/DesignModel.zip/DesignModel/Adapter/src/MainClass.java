
public class MainClass {
	public static void main(String[] args) {
//        Current current=new Current();
//        current.user220V();
        
        //�̳�
        Adapter adapter=new Adapter();
        adapter.user18v();
        //ί��
        Adapter2 adapter2=new Adapter2(new Current());
        adapter2.use18v();
	}
}
