
/**
 * ƽ�����̶�
 * @author LiNian
 *
 */
public class PingFangBuilder implements HouseBuilder {

	House house=new House();
	
	@Override
	public void makeFloor() {
		// TODO Auto-generated method stub
        house.setFloor("ƽ��-�ذ�");
	}

	@Override
	public void makeWall() {
		// TODO Auto-generated method stub
        house.setWall("ƽ��-ǽ");
	}

	@Override
	public void makeHouseTop() {
		// TODO Auto-generated method stub
       house.setHousetop("ƽ��-��");
	}

	@Override
	public House getHouse() {
		// TODO Auto-generated method stub
		return house;
	}

}
