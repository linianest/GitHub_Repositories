
public class HouseDirector {

	private HouseBuilder builder;
	
	public HouseDirector(HouseBuilder builder){
		this.builder=builder;
	}
	
	public void makeHouse(){
		builder.makeHouseTop();
		builder.makeFloor();
		builder.makeWall();
	}
}
