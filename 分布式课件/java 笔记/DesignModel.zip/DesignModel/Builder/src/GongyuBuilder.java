
public class GongyuBuilder implements HouseBuilder{

	House house=new House();
	@Override
	public void makeFloor() {
		// TODO Auto-generated method stub
		house.setFloor("��Ԣ--�ذ�");
	}

	@Override
	public void makeWall() {
		// TODO Auto-generated method stub
		house.setWall("��Ԣ--ǽ");
	}

	@Override
	public void makeHouseTop() {
		// TODO Auto-generated method stub
		house.setHousetop("��Ԣ--��");
	}

	@Override
	public House getHouse() {
		// TODO Auto-generated method stub
		return house;
	}

}
