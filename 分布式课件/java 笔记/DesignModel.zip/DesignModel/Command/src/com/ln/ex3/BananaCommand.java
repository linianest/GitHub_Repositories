package com.ln.ex3;

public class BananaCommand extends Command{

	public BananaCommand(Peddler peddler) {
		super(peddler);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void sail() {
		this.getPeddler().sailBanana();
	}

}
