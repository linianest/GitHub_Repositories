package com.ln.ex3;

public class MainClass {
	public static void main(String[] args) {
      Peddler peddler=new Peddler();
//      peddler.sailApple();
      Command appleCommand=new AppleCommand(peddler);
      Command bananaCommand=new BananaCommand(peddler);
      
      Waiter waiter=new Waiter();
      waiter.setOrder(appleCommand);
      waiter.setOrder(bananaCommand);
      waiter.Invorker();      
    
	}
}
