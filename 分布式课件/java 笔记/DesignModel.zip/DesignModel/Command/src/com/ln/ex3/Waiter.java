package com.ln.ex3;

import java.util.ArrayList;
import java.util.List;

public class Waiter {
	
	private List<Command> commands=new ArrayList<Command>();
	private Command command;



	public void setOrder(Command command) {
		commands.add(command);		
	}

	
	public void removeOrder(Command command) {
		commands.remove(command);		
	}
	
	public void Invorker(){
		for(Command command:commands){
			command.sail();	
		}
		
	}

}
