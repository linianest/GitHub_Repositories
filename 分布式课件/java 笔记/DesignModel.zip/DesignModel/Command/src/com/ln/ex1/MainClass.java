package com.ln.ex1;

public class MainClass {
	public static void main(String[] args) {
      Peddler peddler=new Peddler();
      peddler.sailApple();
	}
}
