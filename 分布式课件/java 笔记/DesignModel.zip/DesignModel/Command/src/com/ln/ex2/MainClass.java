package com.ln.ex2;

public class MainClass {
	public static void main(String[] args) {
      Peddler peddler=new Peddler();
//      peddler.sailApple();
      Command command=new AppleCommand(peddler);
      
      Waiter waiter=new Waiter();
      waiter.setCommand(command);
      waiter.sail();      
    
	}
}
