package com.ln.ex3;

/**
 * С�̷�
 * @author LiNian
 *
 */
public class Peddler {

	public void sailApple(){
		System.out.println("��ƻ��");
	}
	public void sailBanana(){
		System.out.println("���㽶");
	}
}
