/**
 * ��װ��
 * @author LiNian
 *
 */
public abstract class MakeCar {

	public abstract void makeHead(); 
	public abstract void makeBody(); 
	public abstract void makeTail(); 
	 
	// ����ģ�巽��
	public void make(){
		this.makeHead();
		this.makeBody();
		this.makeTail();
	}
}
