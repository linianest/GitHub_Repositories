
public class MakeBus extends MakeCar{

	@Override
	public void makeHead() {
		System.out.println("bus:��װ��ͷ");
		
	}

	@Override
	public void makeBody() {
		System.out.println("bus:��װ����");
		
	}

	@Override
	public void makeTail() {
		
		System.out.println("bus:��װ��β");
	}

}
