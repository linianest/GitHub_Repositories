
public class MainClass {
	public static void main(String[] args) {
       String number="10";
       Context context=new Context(number);
       
       Expression expression=new PlusExpression();
       expression.interpret(context);
       System.out.println(context.getOutput());
	}
}
