package com.ln.ex2;

public class MainClass {
	public static void main(String[] args) {

		Person person = new Person("����", "��", 12);

		// �����ڲ�״̬
//		Memento memento = person.createMemento();
		Caretaker caretaker=new Caretaker();
		caretaker.setMemento(person.createMemento());
		System.out.println(person.toString());

		// �޸�
		person.setAge(22);
		System.out.println(person.toString());

		// �ع�����ԭ
		person.setMemento(caretaker.getMemento());
		System.out.println(person.toString());

	}
}
