
public class MainClass {
	public static void main(String[] args) {
		
       Person person=new Person("����", "��", 12);
       
       //�����ڲ�״̬
       Person backup=new Person();
       backup.setName(person.getName());
       backup.setAge(person.getAge());
       backup.setSex(person.getSex());
       
       System.out.println(person.toString());
       
       //�޸�
       person.setAge(22);
       person.toString();
       
       // �ع�����ԭ
       backup.setName(person.getName());
       backup.setAge(person.getAge());
       backup.setSex(person.getSex());
       person.toString();
       
	}
}
