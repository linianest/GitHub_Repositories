import java.util.ArrayList;
import java.util.List;

/**
 * Cloneable�ӿڣ�������������ǿ��Ա���¡��
 * @author LiNian
 *
 */
public class Person implements Cloneable{
	private String name;
	private int age;
	private String sex;
	
	private List<String> list;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}
	
	public List<String> getList() {
		return list;
	}

	public void setList(List<String> list) {
		this.list = list;
	}

	public Person clone(){
		try {
			Person person=(Person)super.clone();
			List<String> friends=new ArrayList<String>();
			for(String friend:this.getList()){
				friends.add(friend);
			}
			person.setList(friends);
			return person;
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}
	
	
}
