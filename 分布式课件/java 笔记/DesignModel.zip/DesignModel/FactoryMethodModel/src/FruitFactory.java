

public interface FruitFactory {
	
	
	public Fruit getFruit();

}
