

public class Banana implements Fruit{
	/**
	 * get
	 */
	public void get(){
		System.out.println("�㽶");
	}

}
