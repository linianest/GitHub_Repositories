
/**
 * ��԰B����
 * 
 * @author LiNian
 *
 */
public class ParkB implements ParkElement {

	public void accept(Visitor visitor) {
     visitor.visitor(this);
	}
}
