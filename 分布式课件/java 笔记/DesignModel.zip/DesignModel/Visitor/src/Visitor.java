
/**
 * ������
 * @author LiNian
 *
 */
public interface Visitor {
	
	public void visitor(Park park);
	public void visitor(ParkA parkA);
	public void visitor(ParkB parkB);

}
