
/**
 * ��԰A����
 * @author LiNian
 *
 */
public class ParkA implements ParkElement{

	public void accept(Visitor visitor) {
		
		visitor.visitor(this);
	}

}
