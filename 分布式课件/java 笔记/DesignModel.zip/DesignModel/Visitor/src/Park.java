
/**
 * ��԰
 * @author LiNian
 *
 */
public class Park implements ParkElement{

	private ParkA parkA;
	private ParkB parkB;
	
	public void accept(Visitor visitor) {
		visitor.visitor(this);
		parkA.accept(visitor);
		parkB.accept(visitor);
	}


	public Park() {
		this.parkA=new ParkA();
		this.parkB=new ParkB();
	}

}
