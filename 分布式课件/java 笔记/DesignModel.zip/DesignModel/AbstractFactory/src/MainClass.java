

public class MainClass {
	
	public static void main(String[] args) {

		//����ˮ��
		FruitFactory ff=new NorthFruitFactory();
		Fruit apple=ff.getApple();
		apple.get();
		Fruit banana=ff.getBanana();
		banana.get();
		
		//�Ϸ�ˮ��
		FruitFactory ff2=new SouthFruitFactory();
		Fruit apple2=ff2.getApple();
		apple2.get();
		Fruit banana2=ff2.getBanana();
		banana2.get();

	}

}
