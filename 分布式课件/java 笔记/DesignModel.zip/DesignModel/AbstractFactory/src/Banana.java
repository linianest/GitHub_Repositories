
public abstract class Banana implements Fruit {
	public abstract void get();
}
