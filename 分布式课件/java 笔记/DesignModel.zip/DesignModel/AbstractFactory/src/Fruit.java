

public interface Fruit {
	
	public void get();

}
