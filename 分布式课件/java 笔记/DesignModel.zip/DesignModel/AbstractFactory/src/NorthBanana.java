
public class NorthBanana extends Banana{

	/**
	 * get
	 */
	public void get(){
		System.out.println("�����㽶");
	}
}
