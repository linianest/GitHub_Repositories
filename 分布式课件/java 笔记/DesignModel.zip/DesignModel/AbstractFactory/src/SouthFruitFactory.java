
public class SouthFruitFactory implements FruitFactory {

	public Fruit getApple() {
		// TODO Auto-generated constructor stub
		return new SouthApple();
	}

	@Override
	public Fruit getBanana() {
		// TODO Auto-generated method stub
		return new SouthBanana();
	}

	
}
