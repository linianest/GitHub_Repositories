

public class SouthApple extends Apple{
	/**
	 * get
	 */
	public void get(){
		System.out.println("�Ϸ�ƻ��");
	}
}
