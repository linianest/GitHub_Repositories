
public abstract class Apple implements Fruit{
     
	public abstract void get();
}
