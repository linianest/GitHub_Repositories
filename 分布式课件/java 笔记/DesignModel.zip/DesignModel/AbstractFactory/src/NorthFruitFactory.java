
public class NorthFruitFactory implements FruitFactory {

	public Apple getApple() {
		// TODO Auto-generated constructor stub
		return new NorthApple();
	}

	@Override
	public Fruit getBanana() {
		// TODO Auto-generated method stub
		return new NorthBanana();
	}	

}
