
public class NorthApple extends Apple{

	/**
	 * get
	 */
	public void get(){
		System.out.println("����ƻ��");
	}
}
