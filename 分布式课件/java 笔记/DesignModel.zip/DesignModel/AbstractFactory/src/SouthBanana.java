

public class SouthBanana extends Banana{
	/**
	 * get
	 */
	public void get(){
		System.out.println("�Ϸ��㽶");
	}
}
