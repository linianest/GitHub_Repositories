package com.ln.ex2;

public class MState extends State{

	@Override
	public void doSomething() {
		// TODO Auto-generated method stub
		System.out.println("�����");
	}

}
