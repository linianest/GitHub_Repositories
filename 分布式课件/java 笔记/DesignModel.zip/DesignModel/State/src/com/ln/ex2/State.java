package com.ln.ex2;

public abstract class State {
  public abstract void doSomething();
}
