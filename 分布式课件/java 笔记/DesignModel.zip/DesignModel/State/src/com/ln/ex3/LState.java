package com.ln.ex3;

public class LState extends State {

	@Override
	public void doSomething(Person person) {
		if (person.getHour() == 12) {
			System.out.println("�����");
		} else {
			person.setState(new NoState());
			person.doSomething();
		}

	}

}
