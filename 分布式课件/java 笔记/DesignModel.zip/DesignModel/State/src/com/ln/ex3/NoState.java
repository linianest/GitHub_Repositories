package com.ln.ex3;

public class NoState extends State {

	@Override
	public void doSomething(Person person) {
		// TODO Auto-generated method stub
		System.out.println(person.getHour() + "δ����");
	}

}
