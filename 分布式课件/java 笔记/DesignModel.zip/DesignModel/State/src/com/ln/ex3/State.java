package com.ln.ex3;

public abstract class State {
  public abstract void doSomething(Person person);
}
