
public class MD5Strategy implements Strategy{

	@Override
	public void encrpty() {
		// TODO Auto-generated method stub
		System.out.println("ִ��md5����");
	}

}
