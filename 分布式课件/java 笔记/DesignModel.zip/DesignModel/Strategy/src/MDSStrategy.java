
public class MDSStrategy implements Strategy{

	@Override
	public void encrpty() {
		// TODO Auto-generated method stub
		System.out.println("ִ��mds����");
	}
}
