
public class MainClass {

	public static void main(String[] args) {
//		Strategy strategy=new MD5Strategy();
//		strategy.encrpty();
		
		Context context=new Context(new MD5Strategy());
		context.encrpty();
	}
}
