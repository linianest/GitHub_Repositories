
public class Book {

	public Book(String name, String price, int iSBN) {
		super();
		this.name = name;
		this.price = price;
		ISBN = iSBN;
	}
	private String name;
	private String price;
	private int ISBN;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public int getISBN() {
		return ISBN;
	}
	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}

	public void display(){
		System.out.println("ISBN="+ISBN+",name="+name+",price="+price);
	}
}
