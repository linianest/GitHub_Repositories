import java.util.Iterator;
import java.util.List;

public class MainClass {

	public static void main(String[] args) {
		
		BookList bookList=new BookList();
		
		Book book1=new Book("010203","java���˼��",90);
		Book book2=new Book("010204","java�����ŵ���ͨ",60);
		
		bookList.addBook(book1);
		bookList.addBook(book2);
		//��һ�ַ�ʽ
//		while(bookList.hashNext()){
//			Book book=bookList.getNext();
//			book.display();
//		}
		
		//�ڶ��ַ�ʽ
//		List<Book> bookDataList=bookList.getBookList();
//		for (int i = 0; i < bookDataList.size(); i++) {
//			Book book=bookDataList.get(i);
//			book.display();
//		}
		
		Iterator iter=bookList.iterator();
		while(iter.hasNext()){
			Book book=(Book) iter.next();
			book.display();
		}
		
	}
}
