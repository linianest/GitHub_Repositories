package com.ln.ex2;

public abstract class CarHandler {

    protected CarHandler carHandler;
    
    public CarHandler setNextHandler(CarHandler carHandler){
    	this.carHandler=carHandler;
    	return carHandler;
    }
 
	public abstract void HandlerCar();
}
