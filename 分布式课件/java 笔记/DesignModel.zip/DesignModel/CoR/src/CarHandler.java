
public abstract class CarHandler {

	public abstract void HandlerCar();
}
