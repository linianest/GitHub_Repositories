
public class MainClass {

	public static void main(String[] args) {
		CarHandler headh=new CarHeadHandler();
		CarHandler bodyh=new CarBodyHandler();
		
		
		headh.HandlerCar();
		bodyh.HandlerCar();
	}
}
