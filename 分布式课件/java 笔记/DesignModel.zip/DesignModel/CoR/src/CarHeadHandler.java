
public class CarHeadHandler extends CarHandler {

	@Override
	public void HandlerCar() {
		// TODO Auto-generated method stub
		System.out.println("��װ��ͷ");
	}

}
