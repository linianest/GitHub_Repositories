package com.ln;

public class Apple implements Fruit{
	/**
	 * get
	 */
	public void get(){
		System.out.println("ƻ��");
	}
}
