package com.ln;

public class FruitFactory {
	
	/**
	 * ���Apple��ʵ��
	 * @return
	 */
	public static Apple getAapple(){
		return new Apple();
	}
	
	/**
	 * ���Banana��ʵ��
	 * @return
	 */
	public static Banana getBanana(){
		return new Banana();
	}
	
	public static Fruit getFruit(String type) throws InstantiationException, IllegalAccessException, ClassNotFoundException{
		//equalsIgnoreCase�����ִ�Сд
		if (type.equalsIgnoreCase("apple")) {
			return Apple.class.newInstance();
		}else if(type.equalsIgnoreCase("banana")) {
			return Banana.class.newInstance();
		}else{
			System.out.println("�Ҳ�����Ӧ��ʵ������");
			return null;
		}
		
		
//		Class fruit= Class.forName(type);
//		return (Fruit)fruit.newInstance();
		
	}

}
