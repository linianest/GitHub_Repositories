package com.ln;

public class MainClass {
	
	public static void main(String[] args) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
		//1.��򵥵�new�ؼ��ִ���
//		Apple apple=new Apple();
//		Banana banana=new Banana();
//		apple.get();
//		banana.get();
		
		//2.ͨ���ӿ�ʵ�ֶ�̨�ķ�ʽ
//		Fruit apple=new Apple();
//		Fruit banana=new Banana();
//		apple.get();
//		banana.get();
		
		//3.ͨ�������ķ�ʽ
//		Fruit apple=FruitFactory.getAapple();
//		Fruit banana=FruitFactory.getBanana();
//		apple.get();
//		banana.get();
		
		//3.1ͨ������ģʽ���Σ����ʵ��
		Fruit apple=FruitFactory.getFruit("Apple");
		Fruit banana=FruitFactory.getFruit("Banana");
		apple.get();
		banana.get();
		
//		Fruit apple=FruitFactory.getFruit("com.ln.Apple");
//		Fruit banana=FruitFactory.getFruit("com.ln.Banana");
//		apple.get();
//		banana.get();
	}

}
