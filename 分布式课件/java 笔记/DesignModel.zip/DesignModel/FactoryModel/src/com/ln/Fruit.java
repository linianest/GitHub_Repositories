package com.ln;

public interface Fruit {
	
	public void get();

}
