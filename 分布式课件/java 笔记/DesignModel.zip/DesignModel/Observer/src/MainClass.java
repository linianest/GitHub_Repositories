
public class MainClass {
	public static void main(String[] args) {
        Person person=new Person();
        
        //ע��۲���
        person.addObserver(new MyObserver());
        person.addObserver(new MyObserver());
        //ɾ���۲���
        //person.deleteObservers();
        person.setName("llll");
        person.setAge(12);
        person.setSex("��");
        
	}
}
