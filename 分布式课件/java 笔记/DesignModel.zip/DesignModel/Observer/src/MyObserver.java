import java.util.Observable;
import java.util.Observer;

public class MyObserver implements Observer{

	//�����ص�
	@Override
	public void update(Observable o, Object arg) {

		// TODO Auto-generated method stub
		System.out.println("���۲�Ķ������˱仯");
	//	System.out.println("name="+person.getName());
	}

}
