import java.util.Observable;

/**
 * ���۲��߱���̳�Observable
 * @author LiNian
 *
 */
public class Person extends Observable{

	
	private String name;
	private int age;
	private String sex;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
		//���Զ�������ֵ�Ƿ�ı�
//		System.out.println(this.hasChanged());
		//����ֵ�Ѿ��ı䣬�൱��֪ͨ�����
		this.setChanged();
		this.notifyObservers();
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
		this.setChanged();
		this.notifyObservers();
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
		this.setChanged();
		this.notifyObservers();
	}
}
