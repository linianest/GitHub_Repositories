
public class RealSubject implements Subject{

	@Override
	public void sailBook() {
		// TODO Auto-generated method stub
		System.out.println("����");
	}
	
	

}
