package com.ln;

public interface Subject {

	public void sailBook();
}
