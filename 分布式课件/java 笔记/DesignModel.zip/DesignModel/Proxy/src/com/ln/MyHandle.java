package com.ln;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class MyHandle implements InvocationHandler{

	private RealSubject realSubject;
	
	public void setRealSubject(RealSubject realSubject) {
		this.realSubject = realSubject;
	}

	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		// TODO Auto-generated method stub
		Object result=null;
		dazhe();
		result=method.invoke(realSubject, args);
		give();
		
		return result;
	}

    public void dazhe(){
    	System.out.println("����");
    }
    public void give(){
    	System.out.println("���ʹ���ȯ");
    }
}
