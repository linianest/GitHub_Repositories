
public class ProxySubject implements Subject{

	private RealSubject realSubject;
	
	public void setRealSubject(RealSubject realSubject) {
		this.realSubject = realSubject;
	}
	
	@Override
	public void sailBook() {
		// TODO Auto-generated method stub
		this.dazhe();
		this.realSubject.sailBook();
		this.give();
	}
	
	public void dazhe(){
		System.out.println("����");
	}
	
	public void give(){
		System.out.println("���ʹ���ȯ");
	}

}
