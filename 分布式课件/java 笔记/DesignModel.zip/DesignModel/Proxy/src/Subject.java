
public interface Subject {

	public void sailBook();
}
