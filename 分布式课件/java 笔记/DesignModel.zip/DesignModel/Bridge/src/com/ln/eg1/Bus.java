package com.ln.eg1;

public abstract class Bus implements Car {

	@Override
	public abstract void installEngine(); 
}
