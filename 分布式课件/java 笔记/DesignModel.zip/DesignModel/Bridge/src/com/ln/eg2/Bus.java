package com.ln.eg2;

public class Bus implements Car{


	@Override
	public void install2000Engine() {
		// TODO Auto-generated method stub
		System.out.println("��װBus2000cc����");
	}

	@Override
	public void install2200Engine() {
		// TODO Auto-generated method stub
		System.out.println("��װBus2200cc����");
	}

	@Override
	public void install2400Engine() {
		// TODO Auto-generated method stub
		System.out.println("��װBus2400cc����");
	}

}
