package com.ln.eg1;

public abstract class Jeep implements Car {

}
