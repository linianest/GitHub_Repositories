package com.ln.eg1;

public class Bus2200 extends Bus {

	@Override
	public void installEngine() {
		// TODO Auto-generated method stub
		System.out.println("��װBus22000cc����");
	}

}
