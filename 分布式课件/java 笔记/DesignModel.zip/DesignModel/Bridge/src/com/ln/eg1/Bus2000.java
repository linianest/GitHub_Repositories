package com.ln.eg1;

public class Bus2000 extends Bus {

	@Override
	public void installEngine() {
		// TODO Auto-generated method stub
		System.out.println("��װBus2000cc����");
	}

}
