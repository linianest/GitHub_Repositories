package com.ln.eg1;

public class Jeep2000 extends Jeep{

	@Override
	public void installEngine() {
		// TODO Auto-generated method stub
		System.out.println("��װJeep2000cc����");
	}

}
