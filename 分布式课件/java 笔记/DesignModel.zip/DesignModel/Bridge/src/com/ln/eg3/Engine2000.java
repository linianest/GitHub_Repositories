package com.ln.eg3;

public class Engine2000 implements Engine{

	@Override
	public void installEngine() {
		// TODO Auto-generated method stub
		System.out.println("��װ2000cc���ͻ�");
	}

}
