package com.ln.eg3;

public class Bus extends Car {

	
	public Bus(Engine engine){
		super(engine);
	}
	
	@Override
	public void installEngine() {
		// TODO Auto-generated method stub
		System.out.print("Bus��װ��");
		this.getEngine().installEngine();
	}

}
