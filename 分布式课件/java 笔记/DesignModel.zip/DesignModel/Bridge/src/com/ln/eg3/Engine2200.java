package com.ln.eg3;

public class Engine2200 implements Engine{

	@Override
	public void installEngine() {
		// TODO Auto-generated method stub
		System.out.println("��װ2200cc���ͻ�");
	}

}
