package com.ln.eg2;

/**
 * ����
 * @author LiNian
 *
 */
public interface Car {
	
	public void install2000Engine();
	public void install2200Engine();
	public void install2400Engine();

}
