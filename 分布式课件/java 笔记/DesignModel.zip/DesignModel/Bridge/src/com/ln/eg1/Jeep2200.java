package com.ln.eg1;

public class Jeep2200 extends Jeep{

	@Override
	public void installEngine() {
		// TODO Auto-generated method stub
		System.out.println("��װJeep2200cc����");
	}

}
