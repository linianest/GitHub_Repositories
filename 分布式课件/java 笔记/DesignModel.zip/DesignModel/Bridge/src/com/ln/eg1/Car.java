package com.ln.eg1;

/**
 * ����
 * @author LiNian
 *
 */
public interface Car {
	
	public void installEngine();

}
