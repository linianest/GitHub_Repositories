package com.ln.eg3;

public class MainClass {
	public static void main(String[] args) {

		Engine engine2000=new Engine2000();
        Engine engine2200=new Engine2200();
        
        Car car1=new Bus(engine2200);
        car1.installEngine();
	}
}
