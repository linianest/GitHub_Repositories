package com.ln.eg3;

public interface Engine {

	public void installEngine();
}
