package com.ln.eg3;

public class Jeep extends Car {

	
	public Jeep(Engine engine){
		super(engine);
	}
	
	@Override
	public void installEngine() {
		// TODO Auto-generated method stub
		System.out.print("Jeep��װ��");
		this.getEngine().installEngine();
	}

}
