package com.ln.eg1;

public class MainClass {
	public static void main(String[] args) {

	}
}
