
public abstract class Car {

	
	public void run(){
		System.out.println("������");
	}
	public void show(){
		
	}
}
