
public class MainClass {
	public static void main(String[] args) {
        Car car=new FlyCar();
        car.show();
	}
}
