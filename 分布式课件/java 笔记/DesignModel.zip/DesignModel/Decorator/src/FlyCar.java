
public class FlyCar extends Car{

	public void show(){
		this.run();
		this.fly();
	}
	public void fly(){
		System.out.println("���Է�");
	}
}
