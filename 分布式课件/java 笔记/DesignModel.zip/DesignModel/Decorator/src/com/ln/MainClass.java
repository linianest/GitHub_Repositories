package com.ln;

public class MainClass {
	public static void main(String[] args) {
        Car car=new RunCar();
        
        FlyCarDecorator flyCarDecorator=new FlyCarDecorator(car); 
        flyCarDecorator.show();
	}
}
