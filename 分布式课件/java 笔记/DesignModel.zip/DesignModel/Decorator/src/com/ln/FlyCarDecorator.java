package com.ln;

public class FlyCarDecorator extends CarDecorator{

    public FlyCarDecorator(Car car) {
		// TODO Auto-generated constructor stub
    	super(car);
	}
	@Override
	public void show() {
		// TODO Auto-generated method stub
		this.getCar().run();
		this.fly();
	}
	
	public void fly(){
		System.out.println("���Է�");
	}

}
