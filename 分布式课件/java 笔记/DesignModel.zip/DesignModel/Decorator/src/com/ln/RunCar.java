package com.ln;

public class RunCar extends Car{

	public void show(){
		this.run();
	}
}
