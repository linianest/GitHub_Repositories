
public class SwimCar extends Car{

	public void show(){
		this.run();
		this.Swim();
	}

	public void Swim(){
		System.out.println("������");
	}
}
