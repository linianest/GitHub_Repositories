package com.ln.eg2;

public class MainClass {
	public static void main(String[] args) {
	 Mediator mediator=new Mediator(); 	
      Persion zhangsan=new Man("����",5,mediator);
      Persion lisi=new Man("����",5,mediator);
      Persion xiaofang=new Woman("С��",5,mediator);
      
      zhangsan.getPartner(lisi);
      zhangsan.getPartner(xiaofang);
     
	}
}
