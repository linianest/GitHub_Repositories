package com.ln.eg1;

public class Man extends Persion{

	public Man(String name, int condition) {
		super(name, condition);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void getPartner(Persion persion){
		if(persion instanceof Man){
			System.out.println("�����Ҳ���ͬ����");
		}else{
			if(this.getCondition()==persion.getCondition()){
				System.out.println(this.getCondition()+"��"+persion.getCondition()+"����");
			}else{
				System.out.println(this.getCondition()+"��"+persion.getCondition()+"������");
			}

		}
	}

	

}
