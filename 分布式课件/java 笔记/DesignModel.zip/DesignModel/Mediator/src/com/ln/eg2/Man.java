package com.ln.eg2;

public class Man extends Persion{

	
	
	public Man(String name, int condition, Mediator mediator) {
		super(name, condition, mediator);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void getPartner(Persion persion){
		this.getMediator().setMan(this);
		this.getMediator().getPartner(persion);
	}

	

}
