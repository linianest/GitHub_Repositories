package com.ln.eg1;

public class MainClass {
	public static void main(String[] args) {
      Persion zhangsan=new Man("����",5);
      Persion xiaofang=new Woman("С��",6);
      zhangsan.getPartner(xiaofang);
	}
}
