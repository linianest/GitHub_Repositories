package com.ln.eg2;

public class Woman extends Persion{



	public Woman(String name, int condition, Mediator mediator) {
		super(name, condition, mediator);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void getPartner(Persion persion){
		this.getMediator().setWoman(this);
		this.getMediator().getPartner(persion);
	}

}
