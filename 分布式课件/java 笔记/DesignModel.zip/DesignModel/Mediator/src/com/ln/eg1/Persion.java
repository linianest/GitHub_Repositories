package com.ln.eg1;

public abstract class Persion {

	private String name;
	
	private int condition;
	
	
	public Persion(String name, int condition) {
		super();
		this.name = name;
		this.condition = condition;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getCondition() {
		return condition;
	}

	public void setCondition(int condition) {
		this.condition = condition;
	}
	
	
	public abstract void getPartner(Persion persion);
}
